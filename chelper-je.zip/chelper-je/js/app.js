/* CHelper-JE 界面逻辑
 * 作者：元宝
 */
(function () {
  'use strict';

  var E = window.CHEngine;
  var $ = function (id) { return document.getElementById(id); };

  var state = {
    set: null,
    versionId: E.DEFAULT_VERSION,
    text: '',
    cursor: 0
  };

  var el = {};

  function init() {
    if (!window.CHELPER_JE_DATA) {
      var st = document.getElementById('structure');
      var ph = document.getElementById('paramHint');
      var eb = document.getElementById('errorBox');
      if (st) st.textContent = '命令数据未能加载';
      if (ph) ph.textContent = '本地打开时同目录的 js 文件可能被浏览器拦截。';
      if (eb) {
        eb.style.display = '';
        eb.textContent = '请使用单文件版 chelper-je.html（样式、引擎、数据全部内联，不依赖任何外部文件）。';
      }
      return;
    }

    el.structure = $('structure');
    el.paramHint = $('paramHint');
    el.errorBox = $('errorBox');
    el.list = $('list');
    el.input = $('cmdInput');
    el.highlight = $('highlight');
    el.versionBtn = $('versionBtn');
    el.copyBtn = $('copyBtn');
    el.clearBtn = $('clearBtn');
    el.modal = $('modal');
    el.modalList = $('modalList');
    el.modalTitle = $('modalTitle');
    el.stat = $('stat');
    el.verNote = $('verNote');

    buildVersionModal();
    loadVersion(state.versionId);

    el.input.addEventListener('input', onInput);
    el.input.addEventListener('keyup', onCursor);
    el.input.addEventListener('click', onCursor);
    el.input.addEventListener('scroll', syncScroll);
    el.input.addEventListener('keydown', onKeyDown);
    // 禁止回车换行（命令只能是一行）
    el.input.addEventListener('beforeinput', function (e) {
      if (e.inputType === 'insertLineBreak' || e.inputType === 'insertParagraph') e.preventDefault();
    });

    el.versionBtn.addEventListener('click', function () {
      el.modal.classList.add('show');
    });
    el.modal.addEventListener('click', function (e) {
      if (e.target === el.modal) el.modal.classList.remove('show');
    });
    $('modalClose').addEventListener('click', function () {
      el.modal.classList.remove('show');
    });
    el.copyBtn.addEventListener('click', doCopy);
    el.normBtn = $('normBtn');
    el.normBtn.addEventListener('click', doNormalize);
    el.clearBtn.addEventListener('click', function () {
      el.input.value = '';
      onInput();
      autoGrow();
      el.input.focus();
    });

    onInput();
    el.input.focus();
  }

  function buildVersionModal() {
    el.modalList.innerHTML = '';
    E.VERSIONS.forEach(function (v) {
      var b = document.createElement('button');
      b.className = 'modal-item';
      b.innerHTML = '<span class="mi-name">' + v.name + '</span><span class="mi-note">' + v.note + '</span>';
      b.addEventListener('click', function () {
        el.modal.classList.remove('show');
        if (v.id !== state.versionId) loadVersion(v.id);
      });
      el.modalList.appendChild(b);
    });
  }

  function loadVersion(id) {
    state.versionId = id;
    state.set = E.buildCommandSet(id);
    el.versionBtn.textContent = '版本';
    el.verNote.textContent = state.set.version.name + '　·　' + state.set.version.note;
    el.stat.textContent = '共 ' + state.set.list.length + ' 条命令';
    onInput();
  }

  function onInput() {
    state.text = el.input.value;
    state.cursor = el.input.selectionStart || 0;
    render();
    autoGrow();
  }

  function onCursor() {
    state.cursor = el.input.selectionStart || 0;
    render();
  }

  function syncScroll() {
    el.highlight.style.transform =
      'translate(' + -el.input.scrollLeft + 'px,' + -el.input.scrollTop + 'px)';
  }

  /** 让输入框高度跟着内容走（1~4 行） */
  function autoGrow() {
    var max = 112;
    el.input.style.height = 'auto';
    var h = el.input.scrollHeight;
    el.input.style.height = Math.min(h, max) + 'px';
    el.input.style.overflowY = h > max ? 'auto' : 'hidden';
    el.highlight.style.height = el.input.style.height;
  }

  function render() {
    var r = E.analyze(state.set, state.text, state.cursor);

    el.structure.textContent = r.structure;

    el.paramHint.textContent = r.paramHint;

    if (r.errors.length === 0) {
      el.errorBox.style.display = 'none';
      el.errorBox.textContent = '';
    } else if (r.errors.length === 1) {
      el.errorBox.style.display = '';
      el.errorBox.textContent = r.errors[0];
    } else {
      el.errorBox.style.display = '';
      el.errorBox.textContent = '可能的错误原因：\n' + r.errors.map(function (e, i) {
        return (i + 1) + '. ' + e;
      }).join('\n');
    }

    renderSuggestions(r.suggestions);
    renderHighlight(r.segments);

    // 软提示（多义匹配）：并入参数提示行，用中性色，不算错误
    if (r.softHints && r.softHints.length) {
      el.paramHint.textContent += '　·　' + r.softHints.join('　·　');
    }

    if (el.normBtn) {
      if (hasCJK(state.text)) el.normBtn.classList.add('hot');
      else el.normBtn.classList.remove('hot');
    }
  }

  function renderSuggestions(list) {
    el.list.innerHTML = '';
    if (!list || list.length === 0) {
      var d = document.createElement('div');
      d.className = 'empty-tip';
      d.textContent = '没有匹配的候选项';
      el.list.appendChild(d);
      return;
    }
    var frag = document.createDocumentFragment();
    var n = Math.min(list.length, 200);
    for (var i = 0; i < n; i++) {
      (function (item) {
        var isStatic = item.kind === 'arg';
        var d = document.createElement('div');
        d.className = isStatic ? 'sug sug-static' : 'sug';
        var t = document.createElement('div');
        t.className = 'sug-name';
        t.textContent = item.title;
        if (isStatic) {
          var tag = document.createElement('span');
          tag.className = 'sug-tag';
          tag.textContent = '待填写';
          t.appendChild(tag);
        }
        var s = document.createElement('div');
        s.className = 'sug-desc';
        s.textContent = item.description || '';
        d.appendChild(t);
        d.appendChild(s);
        if (!isStatic) d.addEventListener('click', function () { applySuggestion(item); });
        frag.appendChild(d);
      })(list[i]);
    }
    el.list.appendChild(frag);
  }

  function renderHighlight(segs) {
    el.highlight.innerHTML = '';
    var frag = document.createDocumentFragment();
    segs.forEach(function (s) {
      var sp = document.createElement('span');
      sp.style.color = s.color;
      sp.textContent = s.text;
      frag.appendChild(sp);
    });
    el.highlight.appendChild(frag);
    syncScroll();
  }

  function applySuggestion(item) {
    var text = el.input.value;
    var toks = text.replace(/^\s*\//, '').split(/\s+/);
    var pos = el.input.selectionStart || 0;

    // 找到光标所在 token 的范围
    var re = /\S+/g, m, start = pos, end = pos;
    while ((m = re.exec(text)) !== null) {
      if (pos >= m.index && pos <= m.index + m[0].length) {
        start = m.index;
        end = m.index + m[0].length;
        break;
      }
    }

    var insert;
    if (item.kind === 'command') {
      insert = item.title.replace(/^\//, '');
    } else if (item.kind === 'arg') {
      return; // 参数占位不插入
    } else {
      insert = item.insert || item.title;
    }

    var before = text.substring(0, start);
    var after = text.substring(end);
    var needSpace = after.length === 0 || after.charAt(0) !== ' ';
    var newText = before + insert + (needSpace ? ' ' : '');
    var newPos = before.length + insert.length + (needSpace ? 1 : 0);

    el.input.value = newText;
    el.input.setSelectionRange(newPos, newPos);
    el.input.focus();
    onInput();
    // 长命令时把光标滚进可视区，避免"后面看不见"
    el.input.scrollTop = el.input.scrollHeight;
    var sl = el.input.scrollWidth - el.input.clientWidth;
    if (sl > 0) el.input.scrollLeft = sl;
    syncScroll();
  }

  function onKeyDown(e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      var first = el.list.querySelector('.sug:not(.sug-static)');
      if (first) first.click();
    }
  }

  function hasCJK(s) {
    return /[㐀-鿿　-〿＀-￯]/.test(s);
  }

  function doNormalize() {
    var v = el.input.value;
    if (!v) return;
    var res = E.normalize(state.set, v);
    if (!res.replaced.length) {
      el.normBtn.textContent = '没有需要转换的中文';
      setTimeout(function () { resetNormBtn(); }, 1200);
      return;
    }
    el.input.value = res.text;
    var n = res.replaced.length;
    el.normBtn.textContent = '已转换 ' + n + ' 处';
    setTimeout(function () { resetNormBtn(); }, 1200);
    onInput();
    el.input.focus();
  }

  function resetNormBtn() {
    el.normBtn.textContent = '中文 → ID（转成可粘贴的命令）';
  }

  function doCopy() {
    var v = el.input.value;
    if (!v) return;
    var done = function () {
      var old = el.copyBtn.textContent;
      el.copyBtn.textContent = '已复制';
      setTimeout(function () { el.copyBtn.textContent = old; }, 900);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(v).then(done, fallback);
    } else {
      fallback();
    }
    function fallback() {
      el.input.select();
      try { document.execCommand('copy'); done(); } catch (err) { alert('复制失败，请手动选择复制'); }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
