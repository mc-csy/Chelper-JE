/* CHelper-JE 值域：模糊搜索 + 上下文取值
 * 作者：元宝
 */
(function (global) {
  'use strict';

  var DATA = global.CHELPER_JE_DATA;
  var VALS = DATA.vals;
  var GMETA = DATA.gameruleMeta;

  // ---------- 值域元数据 ----------
  // step: 扁平数组步长；kind: 展示用标签
  var META = {
    item: { step: 2, kind: '物品' },
    block: { step: 2, kind: '方块' },
    entity: { step: 2, kind: '实体' },
    effect: { step: 2, kind: '状态效果' },
    attribute: { step: 2, kind: '属性' },
    sound: { step: 2, kind: '声音' },
    damage: { step: 2, kind: '伤害类型' },
    biome: { step: 2, kind: '生物群系' },
    gamerule: { step: 2, kind: '游戏规则' },
    selector: { step: 2, kind: '目标选择器' },
    dimension: { step: 2, kind: '维度' },
    anchor: { step: 2, kind: '基准部位' },
    heightmap: { step: 2, kind: '高度图' },
    slot: { step: 2, kind: '物品栏槽位' },
    enchant: { step: 3, kind: '魔咒' },
    // ---- 全量补充 ----
    particle: { step: 2, kind: '粒子' },
    potion: { step: 2, kind: '药水' },
    structure: { step: 2, kind: '结构' },
    structure_tag: { step: 2, kind: '结构标签' },
    advancement: { step: 2, kind: '进度' },
    recipe: { step: 2, kind: '配方' },
    loot_table: { step: 2, kind: '战利品表' },
    configured_feature: { step: 2, kind: '配置地物' },
    placed_feature: { step: 2, kind: '放置地物' },
    processor_list: { step: 2, kind: '处理器列表' },
    structure_set: { step: 2, kind: '结构集' },
    poi: { step: 2, kind: '兴趣点' },
    villager_profession: { step: 2, kind: '村民职业' },
    villager_type: { step: 2, kind: '村民类型' },
    fluid: { step: 2, kind: '流体' },
    menu: { step: 2, kind: '容器界面' },
    game_event: { step: 2, kind: '游戏事件' },
    block_entity_type: { step: 2, kind: '方块实体' },
    creative_tab: { step: 2, kind: '创造物品栏' },
    map_decoration: { step: 2, kind: '地图图标' },
    custom_stat: { step: 2, kind: '统计项' },
    stat_type: { step: 2, kind: '统计类型' },
    block_type: { step: 2, kind: '方块类型' },
    trigger_type: { step: 2, kind: '触发器' },
    trim_pattern: { step: 2, kind: '纹样' },
    trim_material: { step: 2, kind: '纹样材料' },
    instrument: { step: 2, kind: '乐器' },
    jukebox_song: { step: 2, kind: '唱片' },
    banner_pattern: { step: 2, kind: '旗帜图案' },
    decorated_pot_pattern: { step: 2, kind: '陶罐图案' },
    painting_variant: { step: 2, kind: '画作' },
    cat_variant: { step: 2, kind: '猫变种' },
    wolf_variant: { step: 2, kind: '狼变种' },
    wolf_sound_variant: { step: 2, kind: '狼声音变种' },
    frog_variant: { step: 2, kind: '青蛙变种' },
    pig_variant: { step: 2, kind: '猪变种' },
    cow_variant: { step: 2, kind: '牛变种' },
    chicken_variant: { step: 2, kind: '鸡变种' },
    trial_spawner: { step: 2, kind: '试炼刷怪笼' },
    dimension_type: { step: 2, kind: '维度类型' },
    chat_type: { step: 2, kind: '聊天类型' },
    item_tag: { step: 2, kind: '物品标签' },
    block_tag: { step: 2, kind: '方块标签' },
    entity_type_tag: { step: 2, kind: '实体标签' },
    fluid_tag: { step: 2, kind: '流体标签' },
    game_event_tag: { step: 2, kind: '游戏事件标签' },
    enchantment_tag: { step: 2, kind: '魔咒标签' },
    damage_type_tag: { step: 2, kind: '伤害类型标签' },
    biome_tag: { step: 2, kind: '生物群系标签' }
  };

  // ---------- 参数 → 值域 映射 ----------
  // 优先按 (命令 id, 参数 key) 精确匹配，其次按 (参数 key)，最后按参数类型兜底
  var BY_CMD_KEY = {
    // 物品 / 方块
    'give|item': 'item',
    'clear|item': 'item',
    'item|item': 'item',
    'loot|tool': 'item',
    'setblock|block': 'block',
    'fill|block': 'block',
    'fill|filter': 'block',
    // 实体
    'summon|entity': 'entity',
    'execute|entity': 'entity',
    'damage|entity': 'selector',
    // 魔咒 / 效果 / 属性
    'enchant|enchantment': 'enchant',
    'effect|effect': 'effect',
    'attribute|attribute': 'attribute',
    // 声音
    'playsound|sound': 'sound',
    'stopsound|sound': 'sound',
    // 伤害
    'damage|damageType': 'damage',
    'damage|damagetype': 'damage',
    // 生物群系
    'locate|biome': 'biome',
    'fillbiome|biome': 'biome',
    'execute|biome': 'biome',
    // 结构 / 兴趣点 / 地物
    'locate|structure': 'structure',
    'locate|poi': 'poi',
    'place|feature': 'placed_feature',
    'place|structure': 'structure',
    'place|pool': 'structure',
    // 进度 / 配方 / 战利品表
    'advancement|advancement': 'advancement',
    'recipe|recipe': 'recipe',
    'loot|loot_table': 'loot_table',
    'loot|loottable': 'loot_table',
    // 粒子
    'particle|name': 'particle',
    // 游戏规则
    'gamerule|rule': 'gamerule',
    // 属性 ID（attribute 命令的 modifier uuid 参数不弹值域）
    'attribute|id': null,
    // 自定义数据，无表
    'data|target': null,
    'data|source': null,
    'function|name': null,
    'dialog|dialog': null,
    'execute|predicate': null,
    'execute|function': null,
    'test|tests': null
  };

  var BY_KEY = {
    enchantment: 'enchant',
    sound: 'sound',
    biome: 'biome',
    attribute: 'attribute',
    damagetype: 'damage',
    dimension: 'dimension',
    anchor: 'anchor',
    heightmap: 'heightmap',
    item: 'item',
    block: 'block',
    slot: 'slot',
    slots: 'slot',
    item_predicate: 'item',
    particle: 'particle',
    potion: 'potion',
    structure: 'structure_tag',
    poi: 'poi',
    advancement: 'advancement',
    recipe: 'recipe',
    loot_table: 'loot_table',
    entity: 'entity',
    fluid: 'fluid',
    menu: 'menu',
    gamemode: null
  };

  // 按参数 key 精确指定（覆盖 BY_KEY）
  var BY_CMD_KEY_EXT = {
    'execute|dimension': 'dimension',
    'execute|entity': 'entity',
    'execute|biome': 'biome',
    'execute|predicate': null,
    'execute|function': null,
    'execute|id': null,
    'bossbar|id': null,
    'data|target': null,
    'data|source': null,
    'function|name': null,
    'schedule|function': null,
    'place|template': null,
    'item|modifier': null,
    'item|slot': 'slot',
    'item|sourceSlot': 'slot',
    'loot|slot': 'slot',
    'dialog|dialog': null,
    'waypoint|style': null,
    'waypoint|color': null,
    'trigger|objective': null,
    'scoreboard|objective': null,
    'team|team': null,
    'tag|name': null,
    'advancement|criterion': null
  };

  /** 判定某命令某参数该弹哪个值域 */
  function valueSetForCmd(cmdId, arg) {
    if (!arg) return null;
    var k = (arg.k || '').toLowerCase();
    var ck = cmdId + '|' + k;
    if (ck in BY_CMD_KEY) return BY_CMD_KEY[ck];
    if (ck in BY_CMD_KEY_EXT) return BY_CMD_KEY_EXT[ck];
    if (k in BY_KEY) return BY_KEY[k];

    // 按参数类型兜底
    var t = arg.t || '';
    if (t === 'item') return 'item';
    if (t === 'block') return 'block';
    if (t === 'selector') return 'selector';

    return null;
  }

  /** 该值域对应的标签值域（#minecraft:xxx 前缀也合法），没有则返回 null。
   *  注意：结构专用标签（cats_spawn_in、*_maps 之类）是内部用途，
   *  不该混进 /locate structure 的结果里，所以 structure 不参与标签补全。 */
  var TAG_OF = {
    item: 'item_tag', block: 'block_tag', entity: 'entity_type_tag',
    fluid: 'fluid_tag', enchant: 'enchantment_tag', damage: 'damage_type_tag',
    biome: 'biome_tag', game_event: 'game_event_tag'
  };

  function tagSetFor(setName) {
    return TAG_OF[setName] || null;
  }

  // ---------- 模糊搜索 ----------
  // cn 字段可能含多个别名，用 "/" 分隔（如 "迅捷/速度/加速"）
  function score(cn, id, q) {
    if (!q) return 1;
    var names = String(cn || '').split('/').filter(function (x) { return x.length > 0; });
    var li = id.toLowerCase();

    // ID 精确 / 前缀
    if (id === q) return 100;
    if (li.indexOf(q) === 0) return 92;

    var best = 0;
    for (var i = 0; i < names.length; i++) {
      var n = names[i].toLowerCase();
      var s = 0;
      if (n === q) s = 98;
      else if (n.indexOf(q) === 0) s = 85;
      else if (n.indexOf(q) > 0) s = 65;
      if (s > best) best = s;
    }
    if (best === 0 && li.indexOf(q) > 0) best = 55;

    // 多词：空格分词，每段都要命中
    var parts = q.split(/\s+/).filter(function (x) { return x.length > 0; });
    if (best === 0 && parts.length > 1) {
      var all = parts.every(function (p) {
        var hitName = names.some(function (n) { return n.indexOf(p) >= 0; });
        return hitName || li.indexOf(p) >= 0;
      });
      if (all) best = 50;
    }
    return best;
  }

  /** 在某值域里搜索，返回 [{id, cn, extra}] */
  function search(setName, query, limit) {
    var flat = VALS[setName];
    var meta = META[setName];
    if (!flat || !meta) return [];
    var q = (query || '').toLowerCase().replace(/^minecraft:/, '');
    var step = meta.step;
    var out = [];
    for (var i = 0; i < flat.length; i += step) {
      var id = flat[i], cn = flat[i + 1];
      var s = score(cn, id, q);
      if (s === 0) continue;
      var item = { id: id, cn: cn, s: s };
      if (step === 3) item.extra = flat[i + 2];
      out.push(item);
    }
    out.sort(function (a, b) {
      if (b.s !== a.s) return b.s - a.s;
      return a.id.length - b.id.length;
    });
    return limit ? out.slice(0, limit) : out;
  }

  /** 查某 ID 的中文名（多个别名时取第一个） */
  function cnOf(setName, id) {
    var flat = VALS[setName];
    var meta = META[setName];
    if (!flat) return '';
    for (var i = 0; i < flat.length; i += meta.step) {
      if (flat[i] === id) return (flat[i + 1] || '').split('/')[0];
    }
    return '';
  }

  /** 查附魔最大等级 */
  function enchantMax(id) {
    var flat = VALS.enchant;
    for (var i = 0; i < flat.length; i += 3) {
      if (flat[i] === id) return flat[i + 2];
    }
    return null;
  }

  /** 查游戏规则取值约束 */
  function gameruleMeta(id) {
    return GMETA[id] || null;
  }

  /** 查字面量（命令关键字，如 gamerule 名）的中文别名 */
  function literalCn(setName, id) {
    var flat = VALS[setName];
    if (!flat) return '';
    for (var i = 0; i < flat.length; i += 2) {
      if (flat[i] === id) return flat[i + 1] || '';
    }
    return '';
  }

  global.CHVals = {
    META: META,
    literalCn: literalCn,
    valueSetFor: valueSetForCmd,
    tagSetFor: tagSetFor,
    search: search,
    cnOf: cnOf,
    enchantMax: enchantMax,
    gameruleMeta: gameruleMeta
  };
})(window);
