/* CHelper-JE 命令分析与补全核心
 * 作者：元宝
 * 依赖：window.CHELPER_JE_DATA（数据）、window.CHVals（值域）
 *
 * 关键点：
 *  1. position 类型参数在实际输入里占 3 个 token（~ ~ ~ / 100 64 -200），
 *     匹配语法时必须展开，否则 /setblock ~ ~ ~ 会被判成参数错位。
 *  2. 值域参数（物品/方块/实体/魔咒…）走全表模糊搜索，支持中文、英文、多词。
 *  3. 数值参数带上下文约束：/enchant 的等级上限取自该魔咒的 max_level，
 *     /gamerule 的取值类型与范围取自该规则的定义。
 */
(function (global) {
  'use strict';

  var DATA = global.CHELPER_JE_DATA;
  var V = global.CHVals;

  // ---------- 版本档位 ----------
  var VERSIONS = [
    { id: '1.21.11', name: 'Java 1.21.11+', note: '游戏规则为小写下划线命名（advance_time / spawn_mobs）', remove: [] },
    { id: '1.21.5', name: 'Java 1.21.5 – 1.21.10', note: '游戏规则仍为驼峰命名（doDaylightCycle / doMobSpawning）', remove: ['waypoint'] },
    { id: '1.20.4', name: 'Java 1.20.4 及更早', note: '游戏规则驼峰命名；物品数据用 NBT 花括号 { }', remove: ['test', 'dialog', 'waypoint'] }
  ];
  var DEFAULT_VERSION = '1.21.11';

  var C = {
    cmd: '#9f20a7', literal: '#4571e1', arg: '#0fa0c8',
    sel: '#07c160', num: '#4fad63', text: '#d95a53',
    plain: '#000000', bad: '#ff0000'
  };

  function isArgToken(t) { return t.charAt(0) === '<'; }
  function splitSyntax(label) {
    return label.replace(/^\//, '').split(/\s+/).filter(function (x) { return x.length > 0; });
  }
  function normName(s) { return String(s).replace(/^minecraft:/, ''); }
  function VALS_LEN(name) {
    var flat = DATA.vals[name];
    if (!flat) return 0;
    var st = V.META[name] ? V.META[name].step : 2;
    return Math.floor(flat.length / st);
  }

  /** 参数在实际输入里占几个 token：坐标占 3 个 */
  function tokenWidth(a) {
    if (!a) return 1;
    if (a.t === 'position') return 3;
    return 1;
  }

  /** 把语法展开成逐 token 的模式序列。
   *  坐标参数展开成 3 个节点，每个节点消耗 1 个用户 token，
   *  这样用户输入的下标与模式下标一一对应。 */
  function expand(tokens, argMap) {
    var out = [];
    for (var i = 0; i < tokens.length; i++) {
      var t = tokens[i];
      if (isArgToken(t)) {
        var a = argMap[t] || null;
        var n = tokenWidth(a);
        for (var k = 0; k < n; k++) out.push({ tok: t, arg: a, part: k, n: 1, gsize: n });
      } else {
        out.push({ tok: t, arg: null, part: 0, n: 1, gsize: 1 });
      }
    }
    return out;
  }

  // ---------- 构建命令集 ----------
  function buildCommandSet(versionId) {
    var ver = null;
    for (var i = 0; i < VERSIONS.length; i++) if (VERSIONS[i].id === versionId) ver = VERSIONS[i];
    if (!ver) ver = VERSIONS[0];

    var removeMap = {};
    ver.remove.forEach(function (id) { removeMap[id] = true; });
    var rename = ver.id === '1.21.11' ? null : DATA.gameruleOld;

    var list = [], byId = {};

    DATA.commands.forEach(function (c) {
      if (removeMap[c.id]) return;

      var syn = c.s;
      if (rename && c.id === 'gamerule') {
        syn = [];
        c.s.forEach(function (s) {
          var parts = s.l.split(/\s+/);
          if (parts.length < 2) { syn.push(s); return; }
          var rule = normName(parts[1]);
          var old = rename[rule];
          if (!old) return;
          var nl = parts.slice(0);
          nl[1] = old;
          syn.push({ l: nl.join(' '), a: s.a });
        });
      }

      var item = {
        id: c.id, name: c.n, cat: c.c, desc: c.d, aliases: c.al,
        syn: syn.map(function (s) {
          var toks = splitSyntax(s.l);
          var amap = {}, idx = 0;
          for (var t = 0; t < toks.length; t++) {
            if (isArgToken(toks[t])) { var a = s.a[idx]; if (a) amap[toks[t]] = a; idx++; }
          }
          return { label: s.l, tokens: toks, args: s.a || [], argMap: amap, exp: expand(toks, amap) };
        }),
        chain: null
      };

      if (c.chain) {
        item.chain = c.chain.map(function (e) {
          var toks = splitSyntax(e.l);
          var amap = {}, ai = 0;
          for (var t = 0; t < toks.length; t++) {
            if (isArgToken(toks[t])) { var a = e.a[ai]; if (a) amap[toks[t]] = a; ai++; }
          }
          return { label: e.l, desc: e.d, end: !!e.end, tokens: toks, args: e.a || [], argMap: amap, exp: expand(toks, amap) };
        });
      }

      list.push(item);
      byId[c.id] = item;
    });

    var lookup = {};
    list.forEach(function (c) {
      var names = [c.id];
      c.aliases.forEach(function (a) { names.push(String(a).replace(/^\//, '')); });
      names.forEach(function (n) { if (n) lookup[n] = c; });
    });

    return { version: ver, list: list, byId: byId, lookup: lookup, names: Object.keys(lookup).sort() };
  }

  // ---------- 分词 ----------
  function tokenize(text) {
    var toks = [], re = /\S+/g, m;
    while ((m = re.exec(text)) !== null) toks.push({ text: m[0], start: m.index, end: m.index + m[0].length });
    return toks;
  }
  function tokenIndexAt(toks, cursor) {
    for (var i = 0; i < toks.length; i++) {
      if (cursor >= toks[i].start && cursor <= toks[i].end) return i;
    }
    return toks.length;
  }

  function describeArg(a) {
    if (!a) return '';
    var s = a.req ? '（必填' : '（可选';
    if (a.t === 'number') s += '，数字';
    else if (a.t === 'selector') s += '，目标选择器';
    else if (a.t === 'position') s += '，坐标（3 个值：x y z）';
    else if (a.t === 'resource') s += '，ID';
    else if (a.t === 'item') s += '，物品';
    else if (a.t === 'block') s += '，方块';
    else if (a.t === 'longtext') s += '，文本';
    if (a.con) s += '，' + a.con;
    return s + '）';
  }

  function argColor(a) {
    if (!a) return C.arg;
    if (a.t === 'selector') return C.sel;
    if (a.t === 'number') return C.num;
    return C.arg;
  }

  // ---------- 候选收集 ----------
  function Collector() { this.seen = {}; this.items = []; }
  Collector.prototype.add = function (key, item) {
    // 注意：用 hasOwnProperty 判断，索引 0 是合法值，不能直接用 truthy 判断
    if (this.seen.hasOwnProperty(key)) {
      // 同一取值有带/不带 minecraft: 前缀两种写法时，保留更短的（更好读）
      var old = this.items[this.seen[key]];
      if (old && item.title.length < old.title.length) this.items[this.seen[key]] = item;
      return;
    }
    this.seen[key] = this.items.length;
    this.items.push(item);
  };

  function addValueCandidates(col, setName, query, arg, limit) {
    var list = V.search(setName, query, limit || 60);
    var kind = V.META[setName] ? V.META[setName].kind : '';
    list.forEach(function (x) {
      var desc = x.cn ? (x.cn + '　·　' + x.id) : (kind + '　·　' + x.id);
      if (setName === 'enchant' && x.extra !== undefined) desc += '　（最高 ' + x.extra + ' 级）';
      col.add('val:' + x.id, { title: x.id, description: desc, kind: 'value', insert: x.id, score: x.s });
    });
    // 标签形式（#minecraft:xxx）同样合法，一并给出
    var tagSet = V.tagSetFor(setName);
    if (tagSet) {
      V.search(tagSet, query, 12).forEach(function (x) {
        var tid = '#' + x.id;
        col.add('tag:' + tid, {
          title: tid,
          description: '标签　·　' + (x.cn || x.id),
          kind: 'value', insert: tid, score: x.s - 5
        });
      });
    }
    return list.length;
  }

  /** 数值参数的上下文约束 */
  function numericLimit(cmdId, arg, toks) {
    var out = { min: null, max: null, hint: '' };
    var con = arg && arg.con;
    if (con) {
      var m1 = /min\s+(-?\d+)/.exec(con);
      var m2 = /max\s+(-?\d+)/.exec(con);
      if (m1) out.min = parseInt(m1[1], 10);
      if (m2) out.max = parseInt(m2[1], 10);
    }
    var k = (arg && arg.k || '').toLowerCase();

    if (cmdId === 'enchant' && k === 'level') {
      var enc = null;
      for (var i = 1; i < toks.length; i++) {
        var cand = normName(toks[i].text);
        var encId = cand;
        if (V.enchantMax(cand) === null) {
          // 中文输入：先解析成 ID
          var eh = V.search('enchant', cand, 1);
          if (eh.length && (eh[0].id === cand || eh[0].cn.indexOf(cand) >= 0)) encId = eh[0].id;
        }
        if (V.enchantMax(encId) !== null) { enc = encId; break; }
      }
      if (enc) {
        var lv = V.enchantMax(enc);
        out.max = lv;
        out.hint = '「' + (V.cnOf('enchant', enc) || enc) + '」最高 ' + lv + ' 级';
      } else {
        out.hint = '上限取决于前面填的魔咒';
      }
      return out;
    }

    if (cmdId === 'gamerule' && k === 'value') {
      var rule = toks[1] ? normName(toks[1].text) : null;
      var gm = rule ? V.gameruleMeta(rule) : null;
      if (gm) {
        if (gm.t === 'bool') { out.enumOnly = ['true', 'false']; out.hint = '布尔值'; }
        else {
          if (gm.min !== undefined) out.min = gm.min;
          if (gm.max !== undefined) out.max = gm.max;
          out.hint = '整数';
        }
      }
      return out;
    }

    if (out.min === null && out.max === null && !out.hint) return null;
    return out;
  }

  function limitText(lim) {
    if (!lim) return '';
    var s = [];
    if (lim.min !== null && lim.min !== undefined) s.push('≥ ' + lim.min);
    if (lim.max !== null && lim.max !== undefined) s.push('≤ ' + lim.max);
    return s.length ? '（' + s.join('，') + '）' : '';
  }

  function sortSuggestions(items, lower) {
    var scored = [], plain = [];
    items.forEach(function (x) {
      if (x.score !== undefined) scored.push(x); else plain.push(x);
    });
    scored.sort(function (a, b) { return (b.score - a.score) || (a.title.length - b.title.length); });

    // 普通项：英文 ID 与中文别名都参与匹配
    function rank(x) {
      var an = normName(x.title).toLowerCase();
      var acn = (x.cn || '').toLowerCase();
      if (lower === '') return { hit: 0, len: an.length };
      var i1 = an.indexOf(lower);
      var i2 = acn ? acn.indexOf(lower) : -1;
      if (i1 >= 0 && i2 >= 0) return { hit: Math.min(i1, i2 + 20), len: an.length };
      if (i1 >= 0) return { hit: i1, len: an.length };
      if (i2 >= 0) return { hit: i2 + 20, len: an.length };
      return null;
    }
    var matched = [], rest = [];
    plain.forEach(function (x) {
      var rk = rank(x);
      if (lower === '' || rk) { x.__rk = rk || { hit: 0, len: normName(x.title).length }; matched.push(x); }
      else rest.push(x);
    });
    matched.sort(function (a, b) {
      if (a.__rk.hit !== b.__rk.hit) return a.__rk.hit - b.__rk.hit;
      return a.__rk.len - b.__rk.len;
    });
    return scored.concat(matched, rest);
  }

  /** 收集某个"模式位"上的候选 */
  function collectAt(col, cmd, node, query, toks, ctx) {
    var a = node.arg;
    if (!a) {
      // 关键字（如 /gamerule 的规则名、/effect 的 give/clear）
      var cnLit = cmd.id === 'gamerule' ? V.literalCn('gamerule', normName(node.tok)) : '';
      col.add(normName(node.tok), {
        title: node.tok,
        description: cnLit ? (cnLit.split('/')[0] + '　·　关键字') : '关键字',
        kind: 'literal',
        insert: node.tok,
        cn: cnLit
      });
      return { setName: null, lim: null };
    }
    var setName = V.valueSetFor(cmd.id, a);
    var lim = numericLimit(cmd.id, a, toks);

    if (setName) {
      addValueCandidates(col, setName, query, a, 80);
      // execute 的 targets 也允许直接选实体类型
      if (node.tok === '<targets>' || node.tok === '<entities>' || node.tok === '<target>') {
        addValueCandidates(col, 'selector', query, a, 10);
      }
    } else if (a.opt && a.opt.length) {
      a.opt.forEach(function (o) {
        col.add(normName(o), { title: o, description: (a.cn || '参数') + '　·　' + describeArg(a), kind: 'value', insert: o });
      });
    } else {
      var extra = '';
      if (lim) extra = limitText(lim) + (lim.hint ? '　' + lim.hint : '');
      if (node.gsize > 1) extra += '　第 ' + (node.part + 1) + '/' + node.gsize + ' 个值';
      col.add(node.tok, { title: node.tok, description: (a.cn || '参数') + describeArg(a) + extra, kind: 'arg', insert: null });
    }
    return { setName: setName, lim: lim };
  }

  /** 提示文案 */
  function hintFor(cmd, node, setName, lim, extraNames) {
    var a = node.arg;
    var base = node.tok + '　→　' + (a ? a.cn : '关键字') + describeArg(a);
    if (setName) {
      var kind = V.META[setName] ? V.META[setName].kind : '';
      base += '　【可输中文或英文 ID，共 ' + VALS_LEN(setName) + ' 项' + (kind ? ' · ' + kind : '') + '】';
    }
    if (lim) base += '　' + limitText(lim) + (lim.hint ? '　' + lim.hint : '');
    if (node.gsize > 1) base += '　（正在填第 ' + (node.part + 1) + ' 个值，共 ' + node.gsize + ' 个）';
    if (extraNames && extraNames.length) base += '　（此处还可填：' + extraNames.join(' / ') + '）';
    return base;
  }

  // ---------- 走模式：匹配用户 token [from, to) ----------
  /** 模式匹配。pstart 决定 exp 起点与 toks 起点的对应关系：
   *  pstart=from  → exp 与 toks 整体对齐（普通命令，exp[0] 是命令名）
   *  pstart=0     → exp 是子命令片段，exp[0] 对应 toks[from]（execute 链式） */
  function walk(exp, toks, from, to, pstart) {
    var p = (pstart === undefined) ? from : pstart;
    var i = from;
    while (i < to) {
      if (p >= exp.length) return null;
      var e = exp[p];
      if (!e.arg) {
        if (e.tok.toLowerCase() !== toks[i].text.toLowerCase()) return null;
      }
      i += e.n; p++;
    }
    return { p: p, partial: false };
  }

  /** 子命令是否被完整匹配（用于 execute 链式） */
  function walkExact(exp, toks, from) {
    if (from + exp.length > toks.length) return false;
    var w = walk(exp, toks, from, from + exp.length, 0);
    return !!w && w.p === exp.length;
  }

  // ---------- 主入口 ----------
  function analyze(set, rawText, cursor) {
    var r = { structure: '', segments: [], paramHint: '', errors: [], softHints: [], suggestions: [], empty: false };

    if (cursor === undefined || cursor === null) cursor = rawText.length;
    var text = rawText.replace(/^\s*\//, '');
    var offset = rawText.length - text.length;

    if (text.trim().length === 0) {
      r.empty = true;
      r.structure = '欢迎使用 CHelper-JE';
      r.paramHint = '作者：' + DATA.meta.author + '　|　' + set.version.name;
      r.suggestions = set.list.map(function (c) { return { title: c.name, description: c.desc, kind: 'command' }; });
      return r;
    }

    var toks = tokenize(text);
    var ci = tokenIndexAt(toks, cursor - offset);
    var cur = ci < toks.length ? toks[ci].text : '';

    // --- 命令名阶段 ---
    if (ci === 0) {
      var cmd0 = set.lookup[normName(toks[0].text)];
      r.suggestions = sortSuggestions(set.names.map(function (n) {
        var c = set.lookup[n];
        return { title: '/' + n, description: c.desc, kind: 'command' };
      }), cur.toLowerCase());
      if (!cmd0 && toks.length === 1) {
        r.structure = '正在输入命令名…';
        r.paramHint = '从下方列表点选，或继续输入';
        r.segments = [{ text: text, color: C.plain }];
      } else if (!cmd0) {
        r.errors.push('未知命令：/' + toks[0].text + '（本版本无此命令）');
        r.structure = '/' + toks[0].text;
        r.segments = [{ text: text, color: C.bad }];
      } else {
        r.structure = cmd0.name + ' …';
        r.paramHint = cmd0.desc;
        r.segments = [{ text: text, color: C.cmd }];
      }
      return r;
    }

    var cmd = set.lookup[normName(toks[0].text)];
    if (!cmd) {
      r.errors.push('未知命令：/' + toks[0].text);
      r.structure = '/' + toks[0].text;
      r.segments = [{ text: text, color: C.bad }];
      return r;
    }

    // 值域参数可能被空格切成多段（如 "waxed ox"），把当前段往后拼起来搜
    var query = cur;
    var qEnd = ci;
    if (ci < toks.length) {
      var parts = [cur];
      for (var q = ci + 1; q < toks.length && q <= ci + 2; q++) parts.push(toks[q].text);
      query = parts.join(' ');
    }

    return cmd.chain
      ? analyzeChain(set, cmd, toks, ci, cur, query, r)
      : analyzeFlat(set, cmd, toks, ci, cur, query, r);
  }

  // ---------- 普通命令 ----------
  function analyzeFlat(set, cmd, toks, ci, cur, query, r) {
    var hits = [];
    for (var i = 0; i < cmd.syn.length; i++) {
      var w = walk(cmd.syn[i].exp, toks, 1, ci);
      if (w) hits.push({ syn: cmd.syn[i], w: w });
    }

    if (hits.length === 0) {
      r.errors.push('命令不完整或参数不匹配，请检查已输入的部分');
      r.structure = cmd.name + ' …';
      r.paramHint = cmd.desc;
      r.segments = [{ text: toks.map(function (t) { return t.text; }).join(' '), color: C.bad }];
      return r;
    }

    var col = new Collector();
    var main = null, otherNames = [];
    hits.forEach(function (h) {
      var e = h.syn.exp[h.w.p];
      if (!e) return;
      var res = collectAt(col, cmd, e, query, toks);
      if (!main) {
        main = { node: e, setName: res.setName, lim: res.lim, syn: h.syn, pos: h.w.p };
      } else if (e.tok !== main.node.tok) {
        if (otherNames.indexOf(e.tok) < 0) otherNames.push(e.tok);
      }
    });

    // 跨参数组合搜索：用户把带空格的多词 ID 拆到了两个参数里
    // （如 "waxed oxidized" 被切成 item=waxed、count=oxidized）
    if (main && main.node.arg && main.node.arg.t === 'number' && cur && !/^-?[\d.]/.test(cur)) {
      var prevVal = null, prevSet = null;
      for (var pi = main.pos - 1; pi >= 1; pi--) {
        var pe = main.syn.exp[pi];
        if (!pe) break;
        if (pe.arg) {
          var ps = V.valueSetFor(cmd.id, pe.arg);
          if (ps && toks[pi]) { prevVal = toks[pi].text; prevSet = ps; }
          break;
        }
      }
      if (prevVal && prevSet) {
        V.search(prevSet, prevVal + ' ' + cur, 12).forEach(function (x) {
          col.add('val:' + x.id, {
            title: x.id,
            description: '（' + prevVal + ' ' + cur + '）→ ' + (x.cn || '').split('/')[0],
            kind: 'value', insert: null, score: x.s
          });
        });
      }
    }

    r.suggestions = sortSuggestions(col.items, cur.toLowerCase()).slice(0, 300);

    if (main) {
      r.paramHint = hintFor(cmd, main.node, main.setName, main.lim, otherNames);
    } else {
      r.paramHint = cmd.desc;
    }

    // 结构行：取最长语法
    var best = hits[0].syn;
    for (var m = 1; m < hits.length; m++) if (hits[m].syn.tokens.length > best.tokens.length) best = hits[m].syn;
    r.structure = best.label;

    // 校验已填部分
    validateFilled(r, cmd, best, toks, ci);

    r.segments = buildSegments(toks, best.exp, cmd);
    return r;
  }

  // ---------- 链式命令（execute） ----------
  function analyzeChain(set, cmd, toks, ci, cur, query, r) {
    var i = 1, used = [], inNode = null, partEnt = null, startTok = 1, ok = true;

    while (i < ci) {
      var hit = null, partEntry = null;
      for (var c = 0; c < cmd.chain.length; c++) {
        var e = cmd.chain[c];
        if (walkExact(e.exp, toks, i)) { hit = e; break; }
        // 只填了一半：光标正停在这条子命令中间
        if (!partEntry) {
          var w = walk(e.exp, toks, i, ci, 0);
          if (w && w.p < e.exp.length) partEntry = { e: e, w: w };
        }
      }
      if (hit) {
        used.push(hit);
        i += hit.exp.length;
        if (hit.end) break;
      } else if (partEntry) {
        var pn = partEntry.e.exp[partEntry.w.p];
        inNode = { tok: pn.tok, arg: pn.arg, part: pn.part, n: 1, gsize: pn.gsize };
        partEnt = partEntry.e;
        startTok = i;
        i = ci;
        break;
      } else {
        ok = false;
        break;
      }
    }

    if (!ok) {
      r.errors.push('无法识别的子命令：「' + toks[i].text + '」');
      r.structure = cmd.name + ' ' + used.map(function (u) { return u.label; }).join(' ') + ' …';
      r.paramHint = cmd.desc;
      r.segments = [{ text: toks.map(function (t) { return t.text; }).join(' '), color: C.bad }];
      return r;
    }

    var col = new Collector();
    var main = null;

    if (inNode) {
      var res = collectAt(col, cmd, inNode, query, toks);
      main = { node: inNode, setName: res.setName, lim: res.lim };
      // run 已输入、正在填目标命令
      if (partEnt && partEnt.end) {
        r.structure = cmd.name + ' ' + used.map(function (u) { return u.label; }).join(' ') +
          (used.length ? ' ' : '') + partEnt.label;
        r.paramHint = 'run 之后填写要执行的目标命令';
        if (!cur) {
          set.names.forEach(function (n) {
            var c = set.lookup[n];
            col.add('cmd:' + n, { title: n, description: c.desc, kind: 'command', insert: n });
          });
          main = null; // 保留上面的提示文案
        }
      }
    } else {
      var lastEnd = used.length > 0 && used[used.length - 1].end;
      if (lastEnd) {
        // run 之后：给目标命令名，并提示可继续输入
        r.paramHint = 'run 之后填写要执行的目标命令（可继续输入命令名，会实时补全）';
        r.structure = cmd.name + ' ' + used.map(function (u) { return u.label; }).join(' ') + ' <目标命令>';
        if (cur) {
          set.names.forEach(function (n) {
            if (n.indexOf(cur.toLowerCase()) !== 0) return;
            var c = set.lookup[n];
            col.add('cmd:' + n, { title: n, description: c.desc, kind: 'command', insert: n });
          });
        }
      } else {
        // 子命令起点
        cmd.chain.forEach(function (e) {
          var t0 = e.exp[0];
          var a0 = t0.arg;
          var setName = V.valueSetFor(cmd.id, a0);
          if (setName) {
            addValueCandidates(col, setName, query, a0, 40);
          } else if (!a0) {
            col.add(normName(t0.tok), { title: t0.tok, description: e.desc, kind: 'literal', insert: t0.tok });
          }
        });
        // run 之后也允许继续接修饰子命令
        r.paramHint = cmd.desc + '　（下一步：选择子命令）';
        r.structure = cmd.name + (used.length ? ' ' + used.map(function (u) { return u.label; }).join(' ') : ' …');
      }
    }

    r.suggestions = sortSuggestions(col.items, cur.toLowerCase()).slice(0, 300);
    if (main) r.paramHint = hintFor(cmd, main.node, main.setName, main.lim, null);

    var lastEnd2 = used.length > 0 && used[used.length - 1].end;
    var inRunPartial = !!(inNode && partEnt && partEnt.end);
    if (inRunPartial) {
      if (!cur) r.errors.push('命令不完整：run 之后还要写要执行的命令');
    } else if (!lastEnd2 && used.length > 0) {
      r.errors.push('命令不完整：/execute 必须以 run <命令> 结尾');
    } else if (!lastEnd2 && used.length === 0 && !inNode) {
      r.errors.push('命令不完整：/execute 需要至少一个子命令');
    } else if (lastEnd2 && ci >= toks.length && toks.length === used.reduce(function (a, u) { return a + u.exp.length; }, 1)) {
      r.errors.push('命令不完整：run 之后还要写要执行的命令');
    }

    r.segments = buildChainSegments(toks, cmd, used, inNode, startTok);
    return r;
  }

  function totalWidth(exp) { return exp.length; }

  // ---------- 校验已填部分 ----------
  function validateFilled(r, cmd, best, toks, ci) {
    var lastArgTok = null;
    // 校验范围含光标所在 token（用户已输完的部分都要查）
    for (var pi = 1; pi <= ci && pi < toks.length && pi < best.exp.length; pi++) {
      var e = best.exp[pi];
      var val = toks[pi] ? toks[pi].text : '';
      if (!e.arg) continue;

      // 坐标：逐分量校验，一个参数只报一次
      if (e.arg.t === 'position') {
        if (!/^[~^]?-?\d*(\.\d+)?$/.test(val)) {
          if (lastArgTok !== e.tok) {
            r.errors.push('坐标「' + e.tok + '」需要 3 个值（x y z，可用 ~ 或 ^ 前缀）');
            lastArgTok = e.tok;
          }
        }
        continue;
      }

      var setName = V.valueSetFor(cmd.id, e.arg);
      if (e.arg.opt && e.arg.opt.length) {
        if (e.arg.opt.indexOf(val) === -1) {
          r.errors.push('「' + val + '」不是 ' + e.tok + ' 的合法取值');
        }
      } else if (e.arg.t === 'number') {
        if (!/^-?\d+(\.\d+)?$/.test(val)) {
          r.errors.push(e.tok + ' 需要一个数字，当前是「' + val + '」');
        } else {
          var lim = numericLimit(cmd.id, e.arg, toks);
          if (lim) {
            var n = parseFloat(val);
            if (lim.min !== null && lim.min !== undefined && n < lim.min) {
              r.errors.push(e.tok + ' 不能小于 ' + lim.min + '（当前 ' + val + '）');
            }
            if (lim.max !== null && lim.max !== undefined && n > lim.max) {
              r.errors.push(e.tok + ' 不能大于 ' + lim.max + '（当前 ' + val + '）' + (lim.hint ? '：' + lim.hint : ''));
            }
          }
        }
      } else if (setName && val.indexOf('@') !== 0 && val.indexOf('{') !== 0) {
        if (val.indexOf('#') === 0) {
          // 标签形式：在对应标签值域里查
          var tset = V.tagSetFor(setName);
          var tname = normName(val.slice(1));
          var tinfo = tset ? V.cnOf(tset, tname) : '';
          var thit = tset ? V.search(tset, tname, 1) : [];
          if (tset && !(thit.length && thit[0].id === tname)) {
            r.errors.push('「' + val + '」不是已知的' + (V.META[tset] ? V.META[tset].kind : '标签'));
          }
        } else {
          // 值域校验：英文直接查 ID，中文按名字查（名字可能是 "别名1/别名2"）
          var hit = V.search(setName, val, 8);
          var aliases = hit.length ? (hit[0].cn || '').split('/') : [];
          var okVal = hit.length && (hit[0].id === normName(val) || aliases.indexOf(val) >= 0);
          if (okVal) {
            // 精确命中，放行
          } else if (hit.length > 1) {
            // 多个匹配：说明用户指的是其中某一个，提示从列表选，不算错误
            r.softHints.push('「' + val + '」匹配到 ' + hit.length + ' 项' +
              (V.META[setName] ? V.META[setName].kind : '') + '，请从下方列表选择');
          } else if (hit.length === 1) {
            r.errors.push('「' + val + '」不是精确的' + (V.META[setName] ? V.META[setName].kind : '取值') +
              '，是否要填 ' + hit[0].id + (aliases[0] ? '（' + aliases[0] + '）' : '') + '？');
          } else {
            r.errors.push('「' + val + '」不是已知的' + (V.META[setName] ? V.META[setName].kind : '取值'));
          }
        }
      }
    }
  }

  // ---------- 高亮 ----------
  function buildSegments(toks, exp, cmd) {
    var segs = [];
    for (var i = 0; i < toks.length; i++) {
      var e = i < exp.length ? exp[i] : null;
      var color = C.plain;
      if (i === 0) color = C.cmd;
      else if (!e) color = C.bad;
      else if (!e.arg) color = C.literal;
      else color = argColor(e.arg);
      segs.push({ text: toks[i].text, color: color });
      if (i < toks.length - 1) segs.push({ text: ' ', color: C.plain });
    }
    return segs;
  }

  function buildChainSegments(toks, cmd, used, inNode, startTok) {
    var segs = [], i = 0;
    segs.push({ text: toks[0].text, color: C.cmd });
    i = 1;
    used.forEach(function (u) {
      for (var t = 0; t < u.exp.length; t++) {
        var e = u.exp[t];
        var color = e.arg ? argColor(e.arg) : C.literal;
        segs.push({ text: ' ', color: C.plain });
        segs.push({ text: toks[i] ? toks[i].text : e.tok, color: color });
        i++;
      }
    });
    if (inNode) {
      segs.push({ text: ' ', color: C.plain });
      segs.push({ text: toks[i] ? toks[i].text : '', color: C.arg });
      i++;
    }
    while (i < toks.length) {
      segs.push({ text: ' ', color: C.plain });
      segs.push({ text: toks[i].text, color: C.plain });
      i++;
    }
    return segs;
  }

  // ---------- 中文 → ID 规范化 ----------
  /** 在某个值域里按中文名精确查找 */
  function lookupByCn(setName, q) {
    var list = V.search(setName, q, 5);
    for (var i = 0; i < list.length; i++) {
      if (list[i].cn === q) return list[i];
    }
    return list.length ? list[0] : null;
  }

  /** 把整条命令里的中文参数替换成英文 ID。
   *  返回 { text, replaced: [{from, to, cn}] } */
  function normalize(set, rawText) {
    var text = rawText.replace(/^\s*\//, '');
    var toks = tokenize(text);
    var cmd = set.lookup[normName(toks[0].text)];
    var out = toks.map(function (t) { return t.text; });
    var replaced = [];
    if (!cmd || toks.length < 2) return { text: rawText, replaced: replaced };

    // 建立位置 → 参数 的映射
    var map = {};
    if (cmd.chain) {
      // 链式：逐个 token 判定
      var i = 1;
      while (i < toks.length) {
        var hit = null;
        for (var c = 0; c < cmd.chain.length; c++) {
          if (walkExact(cmd.chain[c].exp, toks, i)) { hit = cmd.chain[c]; break; }
        }
        if (!hit) {
          for (var c2 = 0; c2 < cmd.chain.length; c2++) {
            var w = walk(cmd.chain[c2].exp, toks, i, toks.length, 0);
            if (w && w.p < cmd.chain[c2].exp.length) { hit = cmd.chain[c2]; break; }
          }
        }
        if (!hit) break;
        for (var k = 0; k < hit.exp.length && i + k < toks.length; k++) {
          if (hit.exp[k].arg) map[i + k] = hit.exp[k].arg;
        }
        if (hit.end) { i += hit.exp.length; break; }
        i += hit.exp.length;
      }
    } else {
      // 普通：选一条最匹配的语法
      var best = null, bestScore = -1;
      for (var s = 0; s < cmd.syn.length; s++) {
        var w2 = walk(cmd.syn[s].exp, toks, 1, toks.length);
        if (!w2) continue;
        var sc = cmd.syn[s].exp.length - Math.abs(cmd.syn[s].exp.length - toks.length);
        if (sc > bestScore) { bestScore = sc; best = cmd.syn[s]; }
      }
      if (best) {
        for (var p = 1; p < best.exp.length && p < toks.length; p++) {
          if (best.exp[p].arg) map[p] = best.exp[p].arg;
        }
      }
    }

    for (var idx = 1; idx < toks.length; idx++) {
      var val = toks[idx].text;
      if (/^[\x00-\x7F]+$/.test(val)) continue; // 已是英文
      var setName = null;

      var a = map[idx];
      if (a) setName = V.valueSetFor(cmd.id, a);
      // 字面量位置（如 /gamerule 的规则名）也可能有中文别名
      if (!setName && cmd.id === 'gamerule' && idx === 1) setName = 'gamerule';
      if (!setName) continue;

      var hit2 = lookupByCn(setName, val);
      if (hit2) {
        out[idx] = hit2.id;
        replaced.push({ from: val, to: hit2.id, cn: hit2.cn });
      }
    }

    var newText = out.join(' ');
    if (rawText.charAt(0) === '/') newText = '/' + newText;
    return { text: newText, replaced: replaced };
  }

  global.CHEngine = {
    VERSIONS: VERSIONS,
    DEFAULT_VERSION: DEFAULT_VERSION,
    buildCommandSet: buildCommandSet,
    analyze: analyze,
    normalize: normalize,
    meta: DATA.meta
  };
})(window);
