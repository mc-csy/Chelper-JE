# -*- coding: utf-8 -*-
"""Java 版 /execute 链式子命令定义。

Mojang 官方命令树对 execute 这种递归命令只导出了有限深度
（只有 if / unless 分支，缺 as / at / positioned / rotated / store / run 等），
这里手工补齐 1.21 语法，供 CHelper-JE 的链式解析器使用。
"""


def A(k, cn, t="string", req=True, opt=None, con=None):
    """参数定义"""
    d = {"k": k, "cn": cn, "t": t, "req": req}
    if opt:
        d["opt"] = opt
    if con:
        d["con"] = con
    return d


def S(label, desc, args, end=False):
    """子命令条目"""
    return {"l": label, "d": desc, "a": args, "end": end}


POS = lambda k, cn: A(k, cn, "position")
SEL = lambda k, cn: A(k, cn, "selector")
NUM = lambda k, cn, con=None: A(k, cn, "number", True, None, con)
RES = lambda k, cn: A(k, cn, "resource")
STR = lambda k, cn: A(k, cn, "string")

# ---------- 修饰子命令（改变执行上下文，不能结束） ----------
MODIFIERS = [
    S("align <axes>", "把执行位置对齐到方块坐标（向下取整）",
      [A("axes", "要对齐的坐标轴", "string", True,
         ["x", "y", "z", "xy", "xz", "yz", "xyz"])]),
    S("anchored <anchor>", "设定执行的基准点是实体的脚部还是眼部",
      [A("anchor", "基准部位", "string", True, ["eyes", "feet"])]),
    S("as <targets>", "改变命令的执行者，不改变执行位置、朝向和维度",
      [SEL("targets", "新的执行者")]),
    S("at <targets>", "把执行位置、朝向和维度设为指定实体的，不改变执行者",
      [SEL("targets", "参照的实体")]),
    S("facing <pos>", "把执行朝向设为面向指定坐标",
      [POS("pos", "朝向的坐标")]),
    S("facing entity <targets> <anchor>", "把执行朝向设为面向指定实体",
      [SEL("targets", "朝向的实体"),
       A("anchor", "朝向该实体的哪个部位", "string", True, ["eyes", "feet"])]),
    S("in <dimension>", "把执行维度设为指定维度，命令将在该维度执行",
      [A("dimension", "维度", "resource")]),
    S("on <relation>", "把执行者改为与当前执行者有关系的目标",
      [A("relation", "关系", "string", True,
         ["attacker", "controller", "leasher", "origin", "owner",
          "passengers", "riders", "target", "vehicle"])]),
    S("positioned <pos>", "改变执行位置，不改变执行者和朝向",
      [POS("pos", "新的执行位置")]),
    S("positioned as <targets>", "把执行位置设为指定实体的位置",
      [SEL("targets", "参照的实体")]),
    S("positioned over <heightmap>", "把执行位置移到指定高度图之上",
      [A("heightmap", "高度图", "string", True,
         ["world_surface", "motion_blocking", "motion_blocking_no_leaves",
          "ocean_floor", "ocean_floor_wg"])]),
    S("rotated <yaw> <pitch>", "把执行朝向设为指定的 yaw 与 pitch",
      [NUM("yaw", "水平角度"), NUM("pitch", "俯仰角度")]),
    S("rotated as <targets>", "把执行朝向设为指定实体的朝向",
      [SEL("targets", "参照的实体")]),
    S("summon <entity>", "召唤一个实体并让它成为新的执行者",
      [A("entity", "实体", "resource")]),
]

# ---------- 条件子命令 ----------
def conditions(keyword, kw_desc):
    return [
        S("%s biome <pos> <biome>" % keyword, "%s：指定坐标处是否为某生物群系" % kw_desc,
          [POS("pos", "检测的坐标"), A("biome", "生物群系", "resource")]),
        S("%s block <pos> <block>" % keyword, "%s：指定坐标处是否为某方块" % kw_desc,
          [POS("pos", "检测的坐标"), A("block", "方块", "block")]),
        S("%s blocks <start> <end> <destination> all" % keyword,
          "%s：两个区域是否完全一致（含空气）" % kw_desc,
          [POS("start", "区域起始坐标"), POS("end", "区域结束坐标"),
           POS("destination", "对照区域坐标")]),
        S("%s blocks <start> <end> <destination> masked" % keyword,
          "%s：两个区域的非空气方块是否一致" % kw_desc,
          [POS("start", "区域起始坐标"), POS("end", "区域结束坐标"),
           POS("destination", "对照区域坐标")]),
        S("%s data block <sourcePos> <path>" % keyword,
          "%s：方块实体的 NBT 路径是否存在" % kw_desc,
          [POS("sourcePos", "方块坐标"), STR("path", "NBT 路径")]),
        S("%s data entity <source> <path>" % keyword,
          "%s：实体的 NBT 路径是否存在" % kw_desc,
          [SEL("source", "检测的实体"), STR("path", "NBT 路径")]),
        S("%s data storage <source> <path>" % keyword,
          "%s：命令存储的 NBT 路径是否存在" % kw_desc,
          [RES("source", "存储 ID"), STR("path", "NBT 路径")]),
        S("%s dimension <dimension>" % keyword, "%s：执行维度是否为指定维度" % kw_desc,
          [A("dimension", "维度", "resource")]),
        S("%s entity <entities>" % keyword, "%s：是否存在匹配的实体" % kw_desc,
          [SEL("entities", "检测的实体")]),
        S("%s items block <pos> <slots> <item_predicate>" % keyword,
          "%s：方块物品栏指定槽位是否匹配物品" % kw_desc,
          [POS("pos", "方块坐标"), STR("slots", "槽位"), STR("item_predicate", "物品谓词")]),
        S("%s items entity <entities> <slots> <item_predicate>" % keyword,
          "%s：实体物品栏指定槽位是否匹配物品" % kw_desc,
          [SEL("entities", "检测的实体"), STR("slots", "槽位"), STR("item_predicate", "物品谓词")]),
        S("%s loaded <pos>" % keyword, "%s：指定坐标所在的区块是否已加载" % kw_desc,
          [POS("pos", "检测的坐标")]),
        S("%s predicate <predicate>" % keyword, "%s：谓词是否通过" % kw_desc,
          [RES("predicate", "谓词")]),
        S("%s score <target> <targetObjective> < <source> <sourceObjective>" % keyword,
          "%s：目标分数是否小于来源分数" % kw_desc,
          [SEL("target", "目标"), STR("targetObjective", "目标记分项"),
           SEL("source", "来源"), STR("sourceObjective", "来源记分项")]),
        S("%s score <target> <targetObjective> <= <source> <sourceObjective>" % keyword,
          "%s：目标分数是否小于等于来源分数" % kw_desc,
          [SEL("target", "目标"), STR("targetObjective", "目标记分项"),
           SEL("source", "来源"), STR("sourceObjective", "来源记分项")]),
        S("%s score <target> <targetObjective> = <source> <sourceObjective>" % keyword,
          "%s：目标分数是否等于来源分数" % kw_desc,
          [SEL("target", "目标"), STR("targetObjective", "目标记分项"),
           SEL("source", "来源"), STR("sourceObjective", "来源记分项")]),
        S("%s score <target> <targetObjective> > <source> <sourceObjective>" % keyword,
          "%s：目标分数是否大于来源分数" % kw_desc,
          [SEL("target", "目标"), STR("targetObjective", "目标记分项"),
           SEL("source", "来源"), STR("sourceObjective", "来源记分项")]),
        S("%s score <target> <targetObjective> >= <source> <sourceObjective>" % keyword,
          "%s：目标分数是否大于等于来源分数" % kw_desc,
          [SEL("target", "目标"), STR("targetObjective", "目标记分项"),
           SEL("source", "来源"), STR("sourceObjective", "来源记分项")]),
        S("%s score <target> <targetObjective> matches <range>" % keyword,
          "%s：目标分数是否落在指定范围" % kw_desc,
          [SEL("target", "目标"), STR("targetObjective", "目标记分项"),
           STR("range", "范围，如 1..5、..3、4..")]),
        S("%s stopwatch <id> <range>" % keyword,
          "%s：秒表计时是否落在指定范围" % kw_desc,
          [STR("id", "秒表 ID"), STR("range", "范围")]),
        S("%s function <function>" % keyword, "%s：函数返回值是否为真" % kw_desc,
          [RES("function", "函数")]),
    ]


CONDITIONS = (conditions("if", "当条件成立时继续") + conditions("unless", "当条件不成立时继续"))


# ---------- 存储子命令 ----------
def stores(mode, mode_desc):
    return [
        S("store %s block <targetPos> <path>" % mode,
          "%s：把%s存进方块实体的 NBT 路径" % (mode_desc, "结果" if mode == "result" else "成功次数"),
          [POS("targetPos", "方块坐标"), STR("path", "NBT 路径")]),
        S("store %s bossbar <id> max" % mode,
          "%s：把%s设为 BOSS 血条的最大值" % (mode_desc, "结果" if mode == "result" else "成功次数"),
          [RES("id", "血条 ID")]),
        S("store %s bossbar <id> value" % mode,
          "%s：把%s设为 BOSS 血条的当前值" % (mode_desc, "结果" if mode == "result" else "成功次数"),
          [RES("id", "血条 ID")]),
        S("store %s entity <target> <path>" % mode,
          "%s：把%s存进实体的 NBT 路径" % (mode_desc, "结果" if mode == "result" else "成功次数"),
          [SEL("target", "目标实体"), STR("path", "NBT 路径")]),
        S("store %s score <targets> <objective>" % mode,
          "%s：把%s存进记分板分数" % (mode_desc, "结果" if mode == "result" else "成功次数"),
          [SEL("targets", "目标"), STR("objective", "记分项")]),
        S("store %s storage <target> <path>" % mode,
          "%s：把%s存进命令存储" % (mode_desc, "结果" if mode == "result" else "成功次数"),
          [RES("target", "存储 ID"), STR("path", "NBT 路径")]),
    ]


STORES = stores("result", "存储命令结果") + stores("success", "存储命令成功次数")

RUN = [S("run <command>", "执行目标命令（execute 必须以此结尾）",
         [A("command", "要执行的目标命令", "longtext")], end=True)]


def build():
    """返回 execute 的链式子命令表"""
    return MODIFIERS + CONDITIONS + STORES + RUN


if __name__ == "__main__":
    b = build()
    print("execute 子命令条目数:", len(b))
    for x in b[:6]:
        print(" ", x["l"], "|", x["d"])
