# -*- coding: utf-8 -*-
"""从 Mojang 官方命令树生成 CHelper-JE 的中文命令数据集。"""

import json
import re
import sys

sys.path.insert(0, "/data/workspace")
import execute_chain

SRC = "/data/workspace/je_commands.json"
OUT_JS = "/data/workspace/chelper-je/data/commands.js"
OUT_JSON = "/data/workspace/chelper-je/data/commands.json"

# ---------- 命令中文描述 ----------
CMD_CN = {
    "advancement": "给予、移除或检查玩家的进度",
    "attribute": "查询、添加、移除或设置实体属性",
    "ban": "将玩家加入封禁列表",
    "ban-ip": "将 IP 地址加入封禁列表",
    "banlist": "显示封禁列表",
    "bossbar": "创建和修改 BOSS 血条",
    "clear": "清除玩家物品栏中的物品",
    "clone": "将方块从一个区域复制到另一个区域",
    "damage": "对指定实体造成伤害",
    "data": "获取、合并、修改或移除方块实体、实体和命令存储的 NBT 数据",
    "datapack": "控制已加载的数据包",
    "debug": "开始或结束一次调试会话",
    "defaultgamemode": "设置世界的默认游戏模式",
    "deop": "撤销玩家的管理员权限",
    "dialog": "向客户端显示对话框",
    "difficulty": "设置难度等级",
    "effect": "添加或移除状态效果",
    "enchant": "为玩家手持的物品添加魔咒",
    "execute": "在改变执行者、执行位置与角度、添加限制条件的情况下执行另一条命令",
    "experience": "/xp 的别名。添加或移除玩家经验",
    "fetchprofile": "获取玩家档案",
    "fill": "用特定方块填充一个区域",
    "fillbiome": "用特定生物群系填充一个区域",
    "forceload": "强制区块保持加载或取消加载",
    "function": "运行一个函数",
    "gamemode": "设置玩家的游戏模式",
    "gamerule": "设置或查询游戏规则的值",
    "give": "给予玩家一个物品",
    "help": "提供命令的帮助信息",
    "item": "操作物品栏中的物品",
    "jfr": "开始或停止 JFR 性能分析",
    "kick": "将玩家踢出服务器",
    "kill": "杀死实体（玩家、生物、掉落物等）",
    "list": "列出服务器上的玩家",
    "locate": "定位最近的结构、生物群系或兴趣点",
    "loot": "从战利品表生成物品到世界或物品栏",
    "me": "显示一条关于你自己的信息",
    "msg": "/tell 和 /w 的别名。向其他玩家发送私信",
    "op": "授予玩家管理员权限",
    "pardon": "从封禁列表中移除条目",
    "pardon-ip": "从封禁列表中移除 IP 条目",
    "particle": "创建粒子效果",
    "perf": "采集 10 秒的游戏信息和性能指标",
    "place": "在指定位置放置已配置的地物、拼图、模板或结构",
    "playsound": "播放一个声音",
    "publish": "将单人世界开放到局域网",
    "random": "抽取随机值或控制随机数序列",
    "recipe": "给予或收回玩家的合成配方",
    "reload": "从磁盘重新加载战利品表、进度和函数",
    "return": "在函数内控制执行流程并改变返回值",
    "ride": "让实体骑乘其他实体，或停止骑乘",
    "rotate": "改变实体的朝向",
    "save-all": "将服务器保存到磁盘",
    "save-off": "禁用服务器自动保存",
    "save-on": "启用服务器自动保存",
    "say": "向多名玩家显示一条消息",
    "schedule": "延迟执行一个函数",
    "scoreboard": "管理记分板目标和玩家分数",
    "seed": "显示世界种子",
    "setblock": "将一个方块变为另一个方块",
    "setidletimeout": "设置挂机玩家被踢出的时间",
    "setworldspawn": "设置世界出生点",
    "spawnpoint": "设置玩家的重生点",
    "spectate": "让一名旁观模式玩家旁观一个实体",
    "spreadplayers": "将实体传送到随机位置",
    "stop": "关闭服务器",
    "stopsound": "停止正在播放的声音",
    "stopwatch": "秒表，用于在 execute 中做计时条件判断",
    "summon": "召唤一个实体",
    "tag": "管理实体的标签",
    "team": "管理队伍",
    "teammsg": "/tm 的别名。向队伍发送消息",
    "teleport": "/tp 的别名。传送实体",
    "tellraw": "向玩家显示 JSON 文本消息",
    "test": "管理和执行游戏测试（GameTest）",
    "tick": "控制游戏的刻速率",
    "time": "改变或查询世界的游戏时间",
    "title": "管理屏幕上的标题文字",
    "transfer": "将玩家转移到另一个服务器",
    "trigger": "设置要被激活的触发器",
    "version": "显示服务器的游戏版本",
    "waypoint": "管理定位栏上显示的路径点",
    "weather": "设置天气",
    "whitelist": "管理服务器白名单",
    "worldborder": "管理世界边界",
}

CAT_CN = {
    "General": "通用",
    "Admin": "管理",
    "Entities": "实体",
    "World": "世界",
    "Player": "玩家",
    "Items": "物品",
    "Data": "数据",
    "Server": "服务器",
    "Scoreboard": "记分板",
}

# ---------- 参数中文（按 key+type 匹配，其次按 key） ----------
ARG_CN = {
    "targets": "目标选择器",
    "target": "目标",
    "targetpos": "目标坐标",
    "sourcepos": "来源坐标",
    "source": "来源",
    "targetpath": "目标 NBT 路径",
    "sourcepath": "来源 NBT 路径",
    "path": "NBT 路径",
    "pos": "坐标",
    "begin": "起始坐标（区域对角之一）",
    "end": "结束坐标（区域对角之一）",
    "destination": "目标位置坐标",
    "location": "目标坐标",
    "from": "起始坐标",
    "to": "目标坐标",
    "delta": "相对偏移量",
    "value": "值",
    "count": "数量",
    "amount": "数量",
    "index": "序号",
    "start": "起始下标",
    "slot": "物品栏槽位",
    "sourceslot": "来源槽位",
    "item": "物品",
    "block": "方块",
    "filter": "过滤方块",
    "tool": "工具物品",
    "sound": "声音 ID",
    "biome": "生物群系",
    "advancement": "进度",
    "loot_table": "战利品表",
    "objective": "记分项",
    "targetobjective": "目标记分项",
    "sourceobjective": "来源记分项",
    "team": "队伍",
    "name": "名称",
    "id": "ID",
    "attribute": "属性",
    "modifier": "修饰符",
    "effect": "状态效果",
    "message": "消息",
    "reason": "原因",
    "volume": "音量",
    "minvolume": "最小音量",
    "pitch": "音调",
    "speed": "速度",
    "scale": "缩放",
    "distance": "距离",
    "radius": "半径",
    "seed": "种子",
    "range": "范围",
    "time": "时间",
    "duration": "持续时间（刻）",
    "seconds": "秒数",
    "rotation": "旋转",
    "rotationsteps": "旋转步数",
    "template": "模板",
    "sequence": "序列",
    "targetdimension": "目标维度",
    "sourcedimension": "来源维度",
    "dimension": "维度",
    "entities": "实体",
    "players": "玩家",
    "gamemode": "游戏模式",
    "difficulty": "难度",
    "operation": "运算",
    "tests": "测试",
    "numberoftimes": "次数",
    "max": "最大值",
    "min": "最小值",
    "untilfailed": "是否直到失败为止",
    "onlyrequiredtests": "是否只运行必需测试",
    "visible": "是否可见",
    "hideparticles": "是否隐藏粒子",
    "respectteams": "是否尊重队伍",
    "allowcommands": "是否允许命令",
    "includeworldseed": "是否包含世界种子",
    "includesequenceid": "是否包含序列 ID",
    "facinganchor": "朝向基准点",
    "allowed": "是否允许",
    "coloren": "颜色",
    "color": "颜色",
    "style": "样式",
    "fadein": "淡入时间（刻）",
    "stay": "停留时间（刻）",
    "fadeout": "淡出时间（刻）",
    "height": "高度",
    "width": "宽度",
    "angle": "角度",
    "yaw": "水平朝向角",
    "pitchangle": "俯仰角",
    "function": "函数",
    "datapack": "数据包",
    "entity": "实体",
    "score": "分数",
    "level": "等级",
    "limit": "数量上限",
    "spreaddistance": "分散距离",
    "maxrange": "最大范围",
    "under": "高度上限",
    "delay": "延迟",
    "targets_": "目标",
}

# 按类型兜底的中文
TYPE_CN = {
    "selector": "目标选择器",
    "position": "坐标",
    "number": "数字",
    "resource": "资源 ID",
    "enum": "枚举值",
    "string": "文本",
    "block": "方块",
    "item": "物品",
    "longtext": "文本",
}

# ---------- gamerule 新旧名对照（1.21.11 改名） ----------
GAMERULE_OLD = {
    "advance_time": "doDaylightCycle",
    "advance_weather": "doWeatherCycle",
    "keep_inventory": "keepInventory",
    "mob_griefing": "mobGriefing",
    "spawn_mobs": "doMobSpawning",
    "mob_drops": "doMobLoot",
    "block_drops": "doTileDrops",
    "entity_drops": "doEntityDrops",
    "command_block_output": "commandBlockOutput",
    "natural_health_regeneration": "naturalRegeneration",
    "log_admin_commands": "logAdminCommands",
    "show_death_messages": "showDeathMessages",
    "random_tick_speed": "randomTickSpeed",
    "send_command_feedback": "sendCommandFeedback",
    "reduced_debug_info": "reducedDebugInfo",
    "spectators_generate_chunks": "spectatorsGenerateChunks",
    "respawn_radius": "spawnRadius",
    "player_movement_check": "disablePlayerMovementCheck",
    "elytra_movement_check": "disableElytraMovementCheck",
    "max_entity_cramming": "maxEntityCramming",
    "limited_crafting": "doLimitedCrafting",
    "max_command_sequence_length": "maxCommandChainLength",
    "max_command_forks": "maxCommandForkCount",
    "max_block_modifications": "commandModificationBlockLimit",
    "show_advancement_messages": "announceAdvancements",
    "raids": "disableRaids",
    "spawn_phantoms": "doInsomnia",
    "immediate_respawn": "doImmediateRespawn",
    "players_nether_portal_default_delay": "playersNetherPortalDefaultDelay",
    "players_nether_portal_creative_delay": "playersNetherPortalCreativeDelay",
    "drowning_damage": "drowningDamage",
    "fall_damage": "fallDamage",
    "fire_damage": "fireDamage",
    "freeze_damage": "freezeDamage",
    "spawn_patrols": "doPatrolSpawning",
    "spawn_wandering_traders": "doTraderSpawning",
    "spawn_wardens": "doWardenSpawning",
    "forgive_dead_players": "forgiveDeadPlayers",
    "universal_anger": "universalAnger",
    "players_sleeping_percentage": "playersSleepingPercentage",
    "block_explosion_drop_decay": "blockExplosionDropDecay",
    "mob_explosion_drop_decay": "mobExplosionDropDecay",
    "tnt_explosion_drop_decay": "tntExplosionDropDecay",
    "max_snow_accumulation_height": "snowAccumulationHeight",
    "water_source_conversion": "waterSourceConversion",
    "lava_source_conversion": "lavaSourceConversion",
    "global_sound_events": "globalSoundEvents",
    "spread_vines": "doVinesSpread",
    "ender_pearls_vanish_on_death": "enderPearlsVanishOnDeath",
    "max_minecart_speed": "minecartMaxSpeed",
    "tnt_explodes": "tntExplodes",
    "locator_bar": "locatorBar",
    "pvp": "pvp",
    "allow_entering_nether_using_portals": "allowEnteringNetherUsingPortals",
    "spawn_monsters": "spawnMonsters",
    "command_blocks_work": "commandBlocksEnabled",
    "spawner_blocks_work": "spawnerBlocksEnabled",
    "fire_spread_radius_around_player": None,  # 1.21.11 新增，旧版无对应
    "projectiles_can_break_blocks": "projectilesCanBreakBlocks",
}


def arg_cn(a):
    key = (a.get("key") or "").lower()
    typ = a.get("type") or ""
    if key in ARG_CN:
        return ARG_CN[key]
    return TYPE_CN.get(typ, key or "参数")


def cn_for_key_type(key, typ):
    key = (key or "").lower()
    if key in ARG_CN:
        return ARG_CN[key]
    return TYPE_CN.get(typ, key or "参数")


def main():
    src = json.load(open(SRC, encoding="utf-8"))
    base_version = src["version"]

    commands = []
    for c in src["commands"]:
        cid = c["id"]
        syn = []
        for s in c["syntax"]:
            args = []
            for a in s.get("args", []):
                typ = a.get("type", "string")
                args.append(
                    {
                        "k": a.get("key", ""),
                        "cn": cn_for_key_type(a.get("key"), typ),
                        "t": typ,
                        "req": bool(a.get("required", True)),
                        "opt": a.get("options") or None,
                        "con": a.get("constraints") or None,
                    }
                )
            syn.append({"l": s["label"], "a": args})
        item = {
            "id": cid,
            "n": c.get("name") or "/" + cid,
            "c": CAT_CN.get(c.get("category", "General"), "通用"),
            "d": CMD_CN.get(cid, c.get("description") or ""),
            "al": c.get("aliases") or [],
            "s": syn,
        }
        # execute 的官方语法不完整（只有 if/unless），改用手工补齐的链式子命令表
        if cid == "execute":
            item["chain"] = execute_chain.build()
        commands.append(item)

    data = {
        "meta": {
            "name": "CHelper-JE",
            "author": "元宝",
            "edition": "Java Edition",
            "baseVersion": base_version,
            "source": src.get("source", ""),
            "commandCount": len(commands),
            "syntaxCount": sum(len(c["s"]) for c in commands),
        },
        "gameruleOld": {k: v for k, v in GAMERULE_OLD.items() if v},
        "commands": commands,
    }

    js = (
        "/* CHelper-JE 命令数据集\n"
        " * 数据来源：Mojang 官方命令树（data generator）, 版本 %s\n"
        " * 中文说明与整理：元宝\n"
        " * 本文件由 scripts 生成，如需修改请改源数据后重新生成\n"
        " */\n" % base_version
    )
    js += "window.CHELPER_JE_DATA = " + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n"

    with open(OUT_JS, "w", encoding="utf-8") as f:
        f.write(js)
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))

    print("命令数", len(commands))
    print("语法数", data["meta"]["syntaxCount"])
    print("JS 大小", len(js.encode("utf-8")) // 1024, "KB")
    missing = [c["id"] for c in commands if not CMD_CN.get(c["id"])]
    print("未写中文描述的命令:", missing)


if __name__ == "__main__":
    main()
