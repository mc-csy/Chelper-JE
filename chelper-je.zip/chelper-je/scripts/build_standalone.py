# -*- coding: utf-8 -*-
"""把 chelper-je 打包成单文件 HTML。

用途：安卓 / iOS 用文件管理器直接打开时，content:// 或 file:// 协议
往往加载不了同目录的相对资源（css / js）。单文件版把样式、引擎、
命令数据全部内联，不发起任何外部请求，任何打开方式都能用。
"""

import io
import os
import re

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(BASE, "chelper-je.html")


def read(p):
    with io.open(os.path.join(BASE, p), encoding="utf-8") as f:
        return f.read()


def main():
    html = read("index.html")
    css = read("css/style.css")
    data = read("data/commands.js")
    values = read("js/values.js")
    engine = read("js/engine.js")
    app = read("js/app.js")

    # 去掉外链标签
    html = re.sub(r'<link rel="stylesheet" href="css/style\.css">',
                  "<style>\n" + css + "\n</style>", html, count=1)
    html = html.replace('<script src="data/commands.js"></script>',
                        "<script>\n" + data + "\n</script>")
    html = html.replace('<script src="js/values.js"></script>',
                        "<script>\n" + values + "\n</script>")
    html = html.replace('<script src="js/engine.js"></script>',
                        "<script>\n" + engine + "\n</script>")
    html = html.replace('<script src="js/app.js"></script>',
                        "<script>\n" + app + "\n</script>")

    # 确认没有残留外链
    left = re.findall(r'(?:src|href)="(?!data:)([^"]+)"', html)
    left = [x for x in left if not x.startswith("http")]
    if left:
        raise SystemExit("仍有未内联的外部引用: %s" % left)

    # 标题加标记
    html = html.replace("<title>CHelper-JE", "<title>CHelper-JE（单文件版）")

    with io.open(OUT, "w", encoding="utf-8") as f:
        f.write(html)

    size = os.path.getsize(OUT)
    print("已生成:", OUT)
    print("体积: %.0f KB" % (size / 1024.0))
    print("外部资源引用: 无")


if __name__ == "__main__":
    main()
