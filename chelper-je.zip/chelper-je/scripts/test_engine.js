// CHelper-JE 引擎自测
global.window = global;
require('../data/commands.js');
require('../js/values.js');
require('../js/engine.js');

const E = global.CHEngine;
const V = global.CHVals;
let pass = 0, fail = 0;

function expect(cond, msg) {
  if (cond) pass++;
  else { fail++; console.log('   ✗ ' + msg); }
}

const set = E.buildCommandSet('1.21.11');
const setOld = E.buildCommandSet('1.20.4');

console.log('=== 基础 ===');
let r = E.analyze(set, '', 0);
expect(r.suggestions.length === 85, '空输入应列 85 条命令，实际 ' + r.suggestions.length);

r = E.analyze(set, 'gi', 2);
expect(r.suggestions.some(s => s.title === '/give'), 'gi 应匹配 /give');

r = E.analyze(set, 'foo bar', 7);
expect(r.errors.some(e => e.indexOf('未知命令') >= 0), '应报未知命令');

console.log('=== 值域补全 ===');
r = E.analyze(set, 'give @p 钻石剑');
expect(r.suggestions.some(s => s.title === 'diamond_sword'), '钻石剑应匹配 diamond_sword');

r = E.analyze(set, 'give @p 涂蜡的氧化切制铜楼梯');
expect(r.suggestions.some(s => s.title === 'waxed_oxidized_cut_copper_stairs'),
  '涂蜡的氧化切制铜楼梯应匹配，实际 ' + r.suggestions.slice(0, 3).map(s => s.title));

r = E.analyze(set, 'summon 苦力怕');
expect(r.suggestions.some(s => s.title === 'creeper'), '苦力怕应匹配 creeper');

r = E.analyze(set, 'enchant @s 经验修补');
expect(r.suggestions.some(s => s.title === 'mending'), '经验修补应匹配 mending');

r = E.analyze(set, 'effect give @p 速度');
expect(r.suggestions.some(s => s.title === 'speed'), '速度应匹配 speed');

r = E.analyze(set, 'setblock ~ ~ ~ 空气');
expect(r.suggestions.some(s => s.title === 'air'), '空气应匹配 air');

r = E.analyze(set, 'give @p waxed oxidized');
expect(r.suggestions.some(s => s.title.indexOf('waxed') === 0), '多词 waxed ox 应匹配');

console.log('=== 数值限制 ===');
r = E.analyze(set, 'enchant @s sharpness ', 21);
expect(r.paramHint.indexOf('≤ 5') >= 0, 'sharpness 等级上限应为 5，实际 ' + r.paramHint);

r = E.analyze(set, 'enchant @s 锋利 ');
expect(r.paramHint.indexOf('≤ 5') >= 0, '中文锋利也应识别出上限 5');

r = E.analyze(set, 'enchant @s mending ', 19);
expect(r.paramHint.indexOf('≤ 1') >= 0, 'mending 上限应为 1');

r = E.analyze(set, 'enchant @s sharpness 10');
expect(r.errors.some(e => e.indexOf('不能大于 5') >= 0), '超上限应报错');

r = E.analyze(set, 'give @p diamond 0');
expect(r.errors.some(e => e.indexOf('不能小于 1') >= 0), 'count 0 应报错');

r = E.analyze(set, 'gamerule advance_time ', 22);
expect(r.suggestions.some(s => s.title === 'true'), '布尔规则应给 true/false');

r = E.analyze(set, 'gamerule max_entity_cramming ');
expect(r.paramHint.indexOf('≥ 0') >= 0, '数值规则应显示范围');

console.log('=== 坐标（3 个 token） ===');
r = E.analyze(set, 'setblock ~ ~ ~ ', 15);
expect(r.paramHint.indexOf('方块') >= 0, 'setblock 三个坐标后应是方块，实际 ' + r.paramHint);

r = E.analyze(set, 'tp @s 100 64 ', 13);
expect(r.paramHint.indexOf('第 3 个值') >= 0, 'tp 第三个坐标分量提示，实际 ' + r.paramHint);

r = E.analyze(set, 'setblock ~ ~ ~ abc');
expect(r.errors.length > 0, '非法坐标应报错');

console.log('=== execute 链式 ===');
r = E.analyze(set, 'execute ', 8);
expect(r.suggestions.some(s => s.title === 'as'), 'execute 应给 as');
expect(r.suggestions.some(s => s.title === 'store'), 'execute 应给 store');
expect(r.suggestions.some(s => s.title === 'run'), 'execute 应给 run');

r = E.analyze(set, 'execute as @s at @s run give @s diamond 64');
expect(r.errors.length === 0, '完整 execute 不应报错，实际 ' + r.errors.join('/'));

r = E.analyze(set, 'execute as @s');
expect(r.errors.some(e => e.indexOf('run') >= 0), '未收尾应提示 run');

r = E.analyze(set, 'execute if block ~ ~ ~ ');
expect(r.paramHint.indexOf('方块') >= 0, 'if block 坐标后应是方块，实际 ' + r.paramHint);

r = E.analyze(set, 'execute zzz @s', 14);
expect(r.errors.some(e => e.indexOf('无法识别') >= 0), '应报无法识别子命令');

console.log('=== 中文 → ID 规范化 ===');
function norm(t) { return E.normalize(set, t).text; }
expect(norm('give @p 涂蜡的氧化切制铜楼梯 64') === 'give @p waxed_oxidized_cut_copper_stairs 64',
  '规范化 give，实际 ' + norm('give @p 涂蜡的氧化切制铜楼梯 64'));
expect(norm('summon 苦力怕') === 'summon creeper', '规范化 summon');
expect(norm('enchant @s 锋利 3') === 'enchant @s sharpness 3', '规范化 enchant');
expect(norm('effect give @p 速度 60 1') === 'effect give @p speed 60 1', '规范化 effect');
expect(norm('setblock ~ ~ ~ 涂蜡的氧化切制铜楼梯') === 'setblock ~ ~ ~ waxed_oxidized_cut_copper_stairs',
  '规范化 setblock');
expect(norm('give @p diamond 64') === 'give @p diamond 64', '纯英文不应改动');

console.log('=== 版本切换 ===');
expect(set.list.length === 85, '1.21.11 应有 85 条');
expect(!setOld.byId['test'] && !setOld.byId['dialog'], '旧版应移除 test/dialog');
r = E.analyze(setOld, 'gamerule doDay', 14);
expect(r.suggestions.some(s => s.title === 'doDaylightCycle'), '旧版应给驼峰规则名');
r = E.analyze(set, 'gamerule adv', 12);
expect(r.suggestions.some(s => s.title === 'advance_time'), '新版应给下划线规则名');

console.log('\n通过 ' + pass + ' / 失败 ' + fail);
process.exit(fail > 0 ? 1 : 0);
